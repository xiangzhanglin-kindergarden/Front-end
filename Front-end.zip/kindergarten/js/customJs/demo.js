/**
 * Created by Sunshine on 2017/4/4.
 */
var xhr = new XMLHttpRequest();